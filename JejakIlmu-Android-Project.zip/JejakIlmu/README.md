# Jejak Ilmu — Android

Aplikasi Android sederhana untuk mencatat video/kisah yang dipelajari, pelajaran, renungan, amalan, serta pengingat harian.

## Fitur
- Catatan refleksi tersimpan lokal di perangkat.
- Daftar catatan dan jumlah kisah yang sudah dicatat.
- Pengingat harian melalui notifikasi Android.
- Pengingat dijadwalkan ulang setelah perangkat dinyalakan kembali.

## Menghasilkan APK
APK belum dapat dikompilasi langsung di lingkungan ini karena Android SDK tidak tersedia. Project sudah disertai workflow GitHub Actions untuk membangun APK secara otomatis:
1. Ekstrak ZIP ini, lalu unggah isi folder `JejakIlmu` ke repository GitHub baru.
2. Buka tab **Actions** pada repository dan jalankan **Build Jejak Ilmu APK** (atau workflow berjalan otomatis setelah push ke branch `main`).
3. Setelah selesai, buka hasil run workflow dan unduh artifact **Jejak-Ilmu-debug-apk**.
4. Ekstrak artifact untuk mendapatkan `app-debug.apk`, lalu pasang di HP Android. Izinkan pemasangan dari sumber tersebut bila Android memintanya.

Jika memakai komputer dengan Android Studio, buka folder project ini dan pilih **Build > Build Bundle(s) / APK(s) > Build APK(s)**.

Catatan: Android 13 ke atas meminta izin notifikasi saat pertama dibuka. Penghematan baterai dari sebagian merek HP dapat memengaruhi ketepatan waktu notifikasi.

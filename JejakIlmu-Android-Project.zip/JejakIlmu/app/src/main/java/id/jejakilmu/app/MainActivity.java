package id.jejakilmu.app;

import android.Manifest;
import android.app.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.graphics.Typeface;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.view.*;
import android.view.inputmethod.InputMethodManager;
import android.widget.*;
import org.json.JSONArray;
import org.json.JSONObject;
import java.text.SimpleDateFormat;
import java.util.*;

public class MainActivity extends Activity {
    private static final int GREEN = Color.rgb(35,75,57), CREAM = Color.rgb(248,247,240), GOLD = Color.rgb(194,155,83);
    private LinearLayout root, entriesBox;
    private EditText titleInput, lessonInput, reflectionInput, actionInput;
    private TextView countText;
    private android.content.SharedPreferences prefs;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(GREEN); getWindow().setNavigationBarColor(CREAM);
        prefs = getSharedPreferences("jejak_ilmu", MODE_PRIVATE);
        createChannel(); requestNotificationPermission();
        buildScreen(); renderEntries();
    }
    private void buildScreen() {
        ScrollView scroll = new ScrollView(this); scroll.setFillViewport(true); scroll.setBackgroundColor(CREAM);
        root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(dp(20),dp(22),dp(20),dp(32));
        scroll.addView(root); setContentView(scroll);

        TextView brand = text("JEJAK ILMU", 13, GOLD, true); brand.setLetterSpacing(.18f); root.addView(brand);
        TextView heading = text("Belajar. Merenung.\nMengamalkan.", 29, GREEN, true); heading.setPadding(0,dp(8),0,dp(5)); root.addView(heading);
        root.addView(text("Sedikit ilmu setiap hari, perubahan besar sepanjang hidup.",14,0xff68736b,false));

        LinearLayout hero = card(); hero.setBackground(round(GREEN,18)); hero.setPadding(dp(18),dp(18),dp(18),dp(18));
        hero.addView(text("PERJALANAN ILMUMU",11,0xffd8c394,true));
        countText = text("0 kisah tercatat",24,Color.WHITE,true); countText.setPadding(0,dp(7),0,dp(4)); hero.addView(countText);
        hero.addView(text("Tidak harus banyak. Yang penting dipahami dan diamalkan.",13,0xffe3e9e3,false)); root.addView(hero, params(-1,-2,0,dp(20)));

        section("Catat ilmu hari ini", "Tuliskan video atau kisah yang kamu pelajari.");
        titleInput = field("Judul kisah / video"); lessonInput = field("Pelajaran yang kupahami..."); reflectionInput = field("Apa yang menyentuh hati atau membuatku berpikir?"); actionInput = field("Satu hal kecil yang ingin kuamalkan...");
        addInput(titleInput,1); addInput(lessonInput,3); addInput(reflectionInput,3); addInput(actionInput,2);
        Button save = button("Simpan refleksi", GREEN); root.addView(save,params(-1,dp(52),0,dp(12))); save.setOnClickListener(v -> saveEntry());

        section("Pengingat istiqamah", "Pilih waktu untuk diingatkan belajar atau merenung.");
        Button reminder = button("Atur pengingat harian", 0xffe9e5d8); reminder.setTextColor(GREEN); root.addView(reminder,params(-1,dp(50),0,dp(8)));
        reminder.setOnClickListener(v -> chooseReminder());
        TextView reminderStatus = text("Pengingat: "+prefs.getString("reminder_time","Belum diatur"),13,0xff68736b,false); reminderStatus.setPadding(2,0,0,dp(8)); root.addView(reminderStatus);

        section("Jejak yang sudah dipelajari", "Buka kembali catatanmu dan lihat pertumbuhanmu.");
        entriesBox = new LinearLayout(this); entriesBox.setOrientation(LinearLayout.VERTICAL); root.addView(entriesBox);
        TextView footer = text("اللَّهُمَّ انْفَعْنِي بِمَا عَلَّمْتَنِي\nYa Allah, berilah manfaat pada ilmu yang Engkau ajarkan kepadaku.",13,GREEN,false);
        footer.setGravity(Gravity.CENTER); footer.setPadding(0,dp(28),0,dp(4)); root.addView(footer);
    }
    private void section(String title,String sub){ TextView t=text(title,19,GREEN,true); t.setPadding(0,dp(23),0,dp(4)); root.addView(t); root.addView(text(sub,13,0xff68736b,false)); }
    private EditText field(String hint){ EditText e=new EditText(this); e.setHint(hint); e.setTextSize(14); e.setTextColor(0xff26352c); e.setHintTextColor(0xff8b938d); e.setGravity(Gravity.TOP|Gravity.START); e.setPadding(dp(13),dp(11),dp(13),dp(11)); e.setBackground(round(Color.WHITE,12)); return e; }
    private void addInput(EditText e,int lines){ LinearLayout.LayoutParams p=params(-1, lines==1?dp(50):dp(84),0,dp(9)); root.addView(e,p); e.setSingleLine(lines==1); e.setMinLines(lines); e.setMaxLines(lines); }
    private void saveEntry(){
        String title=titleInput.getText().toString().trim(), lesson=lessonInput.getText().toString().trim(), reflection=reflectionInput.getText().toString().trim(), action=actionInput.getText().toString().trim();
        if(title.isEmpty() && lesson.isEmpty() && reflection.isEmpty() && action.isEmpty()){ Toast.makeText(this,"Isi minimal satu bagian dulu, ya.",Toast.LENGTH_SHORT).show(); return; }
        try { JSONArray a=new JSONArray(prefs.getString("entries","[]")); JSONObject o=new JSONObject(); o.put("title",title.isEmpty()?"Catatan ilmu":title); o.put("lesson",lesson); o.put("reflection",reflection); o.put("action",action); o.put("date",new SimpleDateFormat("d MMM yyyy, HH:mm",new Locale("id","ID")).format(new Date())); a.put(o); prefs.edit().putString("entries",a.toString()).apply();
            titleInput.setText(""); lessonInput.setText(""); reflectionInput.setText(""); actionInput.setText(""); ((InputMethodManager)getSystemService(INPUT_METHOD_SERVICE)).hideSoftInputFromWindow(root.getWindowToken(),0); renderEntries(); Toast.makeText(this,"Alhamdulillah, refleksi tersimpan.",Toast.LENGTH_SHORT).show();
        }catch(Exception ex){Toast.makeText(this,"Catatan belum bisa disimpan.",Toast.LENGTH_SHORT).show();}
    }
    private void renderEntries(){ if(entriesBox==null)return; entriesBox.removeAllViews(); try{ JSONArray a=new JSONArray(prefs.getString("entries","[]")); countText.setText(a.length()+ (a.length()==1?" kisah tercatat":" kisah tercatat")); if(a.length()==0){ TextView empty=text("Belum ada catatan. Mulai dari satu kisah sederhana hari ini.",14,0xff68736b,false); empty.setPadding(dp(14),dp(16),dp(14),dp(16)); empty.setBackground(round(Color.WHITE,12)); entriesBox.addView(empty); }
        for(int i=a.length()-1;i>=0;i--){ JSONObject o=a.getJSONObject(i); LinearLayout c=card(); c.setPadding(dp(15),dp(13),dp(15),dp(13)); TextView h=text(o.optString("title"),17,GREEN,true); c.addView(h); c.addView(text(o.optString("date"),11,0xff858d86,false)); addDetail(c,"Pelajaran",o.optString("lesson")); addDetail(c,"Renungan",o.optString("reflection")); addDetail(c,"Amalan",o.optString("action")); entriesBox.addView(c,params(-1,-2,0,dp(10))); }
        }catch(Exception ignored){} }
    private void addDetail(LinearLayout c,String label,String value){ if(value.trim().isEmpty())return; TextView t=text(label+"\n"+value,13,0xff4d5b51,false); t.setPadding(0,dp(9),0,0); c.addView(t); }
    private void chooseReminder(){ Calendar now=Calendar.getInstance(); new TimePickerDialog(this,(v,h,m)->{ Calendar cal=Calendar.getInstance(); cal.set(Calendar.HOUR_OF_DAY,h); cal.set(Calendar.MINUTE,m); cal.set(Calendar.SECOND,0); if(cal.getTimeInMillis()<=System.currentTimeMillis())cal.add(Calendar.DAY_OF_YEAR,1); Intent i=new Intent(this,ReminderReceiver.class); PendingIntent pi=PendingIntent.getBroadcast(this,71,i,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE); AlarmManager am=(AlarmManager)getSystemService(ALARM_SERVICE); am.setRepeating(AlarmManager.RTC_WAKEUP,cal.getTimeInMillis(),AlarmManager.INTERVAL_DAY,pi); String t=String.format(Locale.getDefault(),"%02d:%02d",h,m); prefs.edit().putString("reminder_time",t).apply(); Toast.makeText(this,"Pengingat harian diatur pukul "+t,Toast.LENGTH_LONG).show(); buildScreen(); renderEntries(); },now.get(Calendar.HOUR_OF_DAY),now.get(Calendar.MINUTE),true).show(); }
    private void createChannel(){ if(Build.VERSION.SDK_INT>=26){ NotificationChannel c=new NotificationChannel("jejak_daily","Pengingat Jejak Ilmu",NotificationManager.IMPORTANCE_DEFAULT); c.setDescription("Pengingat belajar dan merenung setiap hari"); ((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).createNotificationChannel(c); } }
    private void requestNotificationPermission(){ if(Build.VERSION.SDK_INT>=33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED) requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},5); }
    private TextView text(String s,int size,int color,boolean bold){ TextView t=new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color); if(bold)t.setTypeface(Typeface.DEFAULT,Typeface.BOLD); return t; }
    private LinearLayout card(){ LinearLayout l=new LinearLayout(this); l.setOrientation(LinearLayout.VERTICAL); l.setBackground(round(Color.WHITE,14)); return l; }
    private android.graphics.drawable.GradientDrawable round(int color,int radius){ android.graphics.drawable.GradientDrawable d=new android.graphics.drawable.GradientDrawable(); d.setColor(color); d.setCornerRadius(dp(radius)); return d; }
    private Button button(String s,int color){ Button b=new Button(this); b.setText(s); b.setTextSize(14); b.setTypeface(Typeface.DEFAULT,Typeface.BOLD); b.setAllCaps(false); b.setTextColor(color==GREEN?Color.WHITE:GREEN); b.setBackground(round(color,13)); return b; }
    private LinearLayout.LayoutParams params(int w,int h,int left,int bottom){ LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(w,h); p.leftMargin=left; p.bottomMargin=bottom; return p; }
    private int dp(int n){return (int)(n*getResources().getDisplayMetrics().density+.5f);}
}

package id.jejakilmu.app;
import android.app.*; import android.content.*; import android.os.Build;
public class ReminderReceiver extends BroadcastReceiver {
 @Override public void onReceive(Context context,Intent intent){
  Intent open=new Intent(context,MainActivity.class); PendingIntent pi=PendingIntent.getActivity(context,72,open,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
  Notification.Builder b=Build.VERSION.SDK_INT>=26?new Notification.Builder(context,"jejak_daily"):new Notification.Builder(context);
  b.setSmallIcon(android.R.drawable.ic_dialog_info).setContentTitle("Waktunya menambah jejak ilmu").setContentText("Satu video, satu pelajaran, satu renungan. Yuk istiqamah!").setContentIntent(pi).setAutoCancel(true);
  ((NotificationManager)context.getSystemService(Context.NOTIFICATION_SERVICE)).notify(72,b.build());
 }
}
